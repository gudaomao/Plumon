module.exports = {
    cookieSecret: 'plumon',
    db: 'plumon',
    host: 'localhost'
};